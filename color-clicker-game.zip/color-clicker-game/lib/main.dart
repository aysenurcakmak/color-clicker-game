import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: OyunEkrani(),
    );
  }
}

class OyunEkrani extends StatefulWidget {
  const OyunEkrani({Key? key}) : super(key: key);

  @override
  State<OyunEkrani> createState() => _OyunEkraniState();
}

class _OyunEkraniState extends State<OyunEkrani> {
  int skor = 0;
  List<Color> renkler = [Colors.green, Colors.yellow, Colors.blue];
  Random rastgele = Random();

  void renkleriDegistir() {
    setState(() {
      renkler.shuffle(rastgele);
    });
  }

  void tiklandi(Color renk) {
    if (renk == Colors.green) {
      skor++;
    }
    renkleriDegistir();
  }

  void oyunuBitir() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Oyun Bitti"),
          content: Text("Skorunuz: $skor"),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text("Kapat"),
            )
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Renkli Kutu Oyunu"),
        centerTitle: true,
        backgroundColor: Colors.brown,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Skor: $skor",
            style: const TextStyle(fontSize: 24),
          ),
          const SizedBox(height: 30),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: renkler.map((renk) {
              return GestureDetector(
                onTap: () => setState(() => tiklandi(renk)),
                child: Container(
                  width: 80,
                  height: 80,
                  color: renk,
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 50),
          ElevatedButton(
            onPressed: oyunuBitir,
            child: const Text("Oyunu Sonlandır"),
          )
        ],
      ),
    );
  }
}
