# Color Clicker Game 🎨

Basit bir Flutter oyunudur.  
Ekrandaki kutulardan **yeşil olana** tıklayarak puan kazanın 🎮  

## Çalıştırmak için:
```bash
flutter pub get
flutter run
```
